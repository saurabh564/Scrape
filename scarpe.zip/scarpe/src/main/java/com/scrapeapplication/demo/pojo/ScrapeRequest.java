package com.scrapeapplication.demo.pojo;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
public class ScrapeRequest {
    @Min(1)
    private int maxPages;
    @Pattern(regexp = "^(?!\\s*$).+")
    private String proxy;
}
