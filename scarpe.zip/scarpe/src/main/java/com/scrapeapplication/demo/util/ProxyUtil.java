package com.scrapeapplication.demo.util;

import java.net.InetSocketAddress;
import java.net.Proxy;

public class ProxyUtil {

    public static Proxy createProxy(String proxyString) {
        if (proxyString == null || proxyString.isEmpty()) {
            return Proxy.NO_PROXY;
        }

        String[] parts = proxyString.split(":");
        if (parts.length != 2) {
            throw new IllegalArgumentException("Invalid proxy format. Use host:port.");
        }

        String host = parts[0];
        int port;
        try {
            port = Integer.parseInt(parts[1]);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Invalid port number.");
        }

        return new Proxy(Proxy.Type.HTTP, new InetSocketAddress(host, port));
    }
}
