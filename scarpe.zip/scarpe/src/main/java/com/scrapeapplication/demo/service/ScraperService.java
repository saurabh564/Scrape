package com.scrapeapplication.demo.service;

import com.scrapeapplication.demo.model.Product;
import com.scrapeapplication.demo.pojo.ScrapeRequest;
import com.scrapeapplication.demo.repository.ProductRepository;
import com.scrapeapplication.demo.util.ProxyUtil;
import com.scrapeapplication.demo.util.RetryUtil;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.Proxy;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

@Service
public class ScraperService {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    private static final String CACHE_KEY = "products";

    public List<Product> scrape(ScrapeRequest request) {
        List<Product> products = new ArrayList<>();
        int productsScraped = 0;
        Proxy proxy = ProxyUtil.createProxy(request.getProxy());

        for (int page = 1; page <= request.getMaxPages(); page++) {
            final int currentPage = page; // Declare final variable to be used in lambda

            Document doc = RetryUtil.retry(() -> {
                try {
                    return Jsoup.connect("https://dentalstall.com/shop?page=" + currentPage)
                            .proxy(proxy)
                            .get();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }, 3, 2000);

            for (Element productElement : doc.select(".product")) {
                String title = productElement.select(".product-title").text();
                double price = Double.parseDouble(productElement.select(".product-price").text().replace("$", ""));
                String imageUrl = productElement.select(".product-image img").attr("src");

                if (!productRepository.existsByProductTitle(title)) {
                    Product product = new Product(generateUniqueId(),title, price, imageUrl);
                    productRepository.save(product);
                    products.add(product);
                    redisTemplate.opsForHash().put(CACHE_KEY, title, product);
                    productsScraped++;
                } else {
                    Product cachedProduct = (Product) redisTemplate.opsForHash().get(CACHE_KEY, title);
                    if (cachedProduct == null || cachedProduct.getProductPrice() != price) {
                        Product product = new Product(generateUniqueId(),title, price, imageUrl);
                        productRepository.save(product);
                        products.add(product);
                        redisTemplate.opsForHash().put(CACHE_KEY, title, product);
                        productsScraped++;
                    }
                }
            }
        }

        redisTemplate.expire(CACHE_KEY, 1, TimeUnit.HOURS); // Set cache expiry
        System.out.println("Total products scraped and updated in DB: " + productsScraped);
        return products;
    }

    private String generateUniqueId() {
        return UUID.randomUUID().toString().replace("-", "").substring(0, 8);
    }
}
