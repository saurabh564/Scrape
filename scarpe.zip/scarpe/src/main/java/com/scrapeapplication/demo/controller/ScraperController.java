package com.scrapeapplication.demo.controller;

import com.scrapeapplication.demo.model.Product;
import com.scrapeapplication.demo.pojo.ScrapeRequest;
import com.scrapeapplication.demo.service.ScraperService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/api/v1/scrape")
public class ScraperController {

    @Autowired
    private ScraperService scraperService;

    @Value("${scraper.auth.token}")
    private String authToken;

    @PostMapping
    public ResponseEntity<?> scrape(@RequestHeader(HttpHeaders.AUTHORIZATION) String token, @Validated @RequestBody ScrapeRequest request) {
        if (!authToken.equals(token)) {
            return new ResponseEntity<>("Unauthorized", HttpStatus.UNAUTHORIZED);
        }

        scraperService.scrape(request);
        return new ResponseEntity<>("Scraping started", HttpStatus.OK);
    }
}
