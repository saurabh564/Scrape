package com.scrapeapplication.demo.repository;

import com.scrapeapplication.demo.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductRepository extends JpaRepository<Product, String> {
    boolean existsByProductTitle(String productTitle);
}
