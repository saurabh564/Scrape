package com.scrapeapplication.demo.model;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity(name = "products")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Product {

    @Id
    @Column(name = "Id")
    private String product_Id;

    @Column(name = "product_title")
    private String productTitle;

    @Column(name = "product_price")
    private double productPrice;

    @Column(name = "path_to_image")
    private String pathToImage;
}
