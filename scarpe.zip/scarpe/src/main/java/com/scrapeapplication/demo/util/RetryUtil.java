package com.scrapeapplication.demo.util;

import java.util.function.Supplier;

public class RetryUtil {
    public static <T> T retry(Supplier<T> supplier, int retries, long delay) {
        for (int i = 0; i < retries; i++) {
            try {
                return supplier.get();
            } catch (Exception e) {
                if (i == retries - 1) {
                    throw e;
                }
                try {
                    Thread.sleep(delay);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    throw new RuntimeException(ie);
                }
            }
        }
        throw new RuntimeException("Failed after retries");
    }
}
